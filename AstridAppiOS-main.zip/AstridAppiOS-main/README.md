# AstridAppiOS
The free public safety app for iOS. (Note: This project has no license, meaning all rights are reserved to the Astrid Team and this code cannot be used freely or publicly without breach of copyright.)
