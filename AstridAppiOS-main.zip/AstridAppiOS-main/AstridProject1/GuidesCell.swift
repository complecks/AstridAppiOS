//
//  GuidesCell.swift
//  AstridProject1
//
//  Created by Harshith Sadhu on 12/30/21.
//

import UIKit

class GuidesCell: UICollectionViewCell {
    @IBOutlet weak var txt: UILabel!
    @IBOutlet weak var img: UIImageView!
    
}
