//
//  NewsCell.swift
//  AstridProject1
//
//  Created by Harshith Sadhu on 12/30/21.
//

import UIKit

class NewsCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
}
