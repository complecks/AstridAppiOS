//
//  CV2.swift
//  AstridProject1
//
//  Created by Harshith Sadhu on 1/2/22.
//

import UIKit

class CV2: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
}
